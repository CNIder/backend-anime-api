# Full GKE Deployment Package - Phase 9 / Project 2

This self-sufficient release contains the files needed to rebuild and deploy the final cloud-native anime API used for the final GKE deployment.

**Note:** This is a self-contained deployment package for source code, Docker build contexts, Kubernetes/Istio manifests, scripts, and documentation. However, deployment still requires a GKE cluster, Artifact Registry, BigQuery access, IAM configuration, and locally provided secrets. The package is based on the final working GKE deployment, but this rebuilt self-sufficient folder was not end-to-end redeployed after packaging because the cloud budget was exhausted.

## Credential Note

The real `cla/JSON-KEY.json` file is not included in this package because it is a private Google service-account credential.

For deployment, create the Kubernetes secret from a local credential file:

```bash
kubectl create secret generic bigsecret \
  --from-file=API_TOKEN=PATH_TO_JSON_KEY.json \
  -n anime-api \
  --dry-run=client -o yaml | kubectl apply -f -
```

The forum/review services expect `app-secret` to exist:

```bash
kubectl create secret generic app-secret \
  --from-literal=API_KEY="default" \
  -n anime-api \
  --dry-run=client -o yaml | kubectl apply -f -
```

## Build Images

Set the project variables:

```bash
export PROJECT_ID=temp-488519
export REGION=europe-west1
export AR_REPO=anime-repo
```

Then run:

```bash
bash scripts/build-all-images.sh
```

## Deploy

The final deployment used the namespace `anime-api`.

Apply the shared resources first:

```bash
kubectl apply -f antonio/k8s/base/namespace.yaml
kubectl apply -f antonio/k8s/base/configmap.yaml
kubectl apply -f antonio/k8s/base/serviceaccount.yaml
```

Configure BigQuery access for the analytics and recommendations pods:

```bash
export PROJECT_ID=temp-488519
export NAMESPACE=anime-api
bash scripts/configure-bigquery-workload-identity.sh
```

This step creates or reuses the Google service account `anime-api-gsa@temp-488519.iam.gserviceaccount.com`, grants it `roles/bigquery.jobUser` and `roles/bigquery.dataViewer`, binds it to the Kubernetes service account `anime-api/anime-api-sa`, and annotates the Kubernetes service account for GKE Workload Identity.

Create the required secrets as described above, then deploy services:

```bash
kubectl apply -f antonio/k8s/analytics/
kubectl apply -f antonio/k8s/recommendations/
kubectl apply -n anime-api -f cla/k8s/catalog-deployment.yaml
kubectl apply -n anime-api -f cla/k8s/user-deployment.yaml
kubectl apply -n anime-api -f cla/k8s/rating-deployment.yaml
kubectl apply -f art/fase7/rbac/
kubectl apply -f art/fase7/deployments/
```

Apply Istio routing and security resources:

```bash
kubectl apply -f antonio/k8s/istio/gateway.yaml
kubectl apply -f antonio/k8s/istio/destinationrules.yaml
kubectl apply -f antonio/k8s/istio/mtls.yaml
kubectl apply -f antonio/k8s/istio/authorization-policies.yaml
kubectl apply -f antonio/k8s/istio/virtualservice-internal.yaml
kubectl apply -f antonio/k8s/istio/virtualservice-public.yaml
```

## Validate

```bash
kubectl get pods -n anime-api
kubectl get svc -n anime-api
kubectl get gateway,virtualservice,destinationrule,authorizationpolicy,peerauthentication -n anime-api
```

After obtaining the Istio ingress IP:

```bash
export INGRESS_IP=REPLACE_WITH_ISTIO_INGRESS_IP

curl "http://$INGRESS_IP/analytics/health"
curl "http://$INGRESS_IP/recommendations/health"
curl "http://$INGRESS_IP/recommendations/index-status"
curl "http://$INGRESS_IP/users"
curl "http://$INGRESS_IP/anime"
curl "http://$INGRESS_IP/rating"
curl "http://$INGRESS_IP/forum"
curl "http://$INGRESS_IP/reviews"
```

## BigQuery Auth Troubleshooting

If `/recommendations/health` or `/recommendations/index-status` reports an error like:

```text
Access Denied: Project temp-488519: User does not have bigquery.jobs.create permission
```

then the analytics/recommendations pod identity does not have BigQuery job permissions. Re-run:

```bash
bash scripts/configure-bigquery-workload-identity.sh
kubectl rollout restart deployment/analytics -n anime-api
kubectl rollout restart deployment/recommendations -n anime-api
```

Then check:

```bash
curl "http://$INGRESS_IP/recommendations/health"
curl "http://$INGRESS_IP/recommendations/index-status"
```
