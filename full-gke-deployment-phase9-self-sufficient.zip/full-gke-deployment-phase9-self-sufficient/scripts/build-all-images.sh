#!/usr/bin/env bash
set -euo pipefail

PROJECT_ID="${PROJECT_ID:-temp-488519}"
REGION="${REGION:-europe-west1}"
AR_REPO="${AR_REPO:-anime-repo}"
REGISTRY="${REGION}-docker.pkg.dev/${PROJECT_ID}/${AR_REPO}"

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

build_image() {
  local context="$1"
  local image="$2"

  echo "Building ${image} from ${context}"
  gcloud builds submit "${ROOT_DIR}/${context}" --tag "${REGISTRY}/${image}"
}

build_image "antonio/services/analytics" "analytics-bq:phase7-user-choice"
build_image "antonio/services/recommendations" "recommendations-bq:phase7-user-choice-ranked-progress"
build_image "cla/services/catalog-service" "catalog-service:latest"
build_image "cla/services/user-service" "user-service:latest"
build_image "cla/services/rating-service" "rating-service:latest"
build_image "art/services/forum_service" "forum-service:latest"
build_image "art/services/review_service" "review-service:latest"

echo "All images submitted to ${REGISTRY}"
