#!/usr/bin/env bash
set -euo pipefail

PROJECT_ID="${PROJECT_ID:-temp-488519}"
NAMESPACE="${NAMESPACE:-anime-api}"
KSA_NAME="${KSA_NAME:-anime-api-sa}"
GSA_NAME="${GSA_NAME:-anime-api-gsa}"
GSA_EMAIL="${GSA_EMAIL:-${GSA_NAME}@${PROJECT_ID}.iam.gserviceaccount.com}"

echo "Configuring BigQuery Workload Identity for:"
echo "  Project: ${PROJECT_ID}"
echo "  Kubernetes service account: ${NAMESPACE}/${KSA_NAME}"
echo "  Google service account: ${GSA_EMAIL}"

gcloud iam service-accounts describe "${GSA_EMAIL}" \
  --project "${PROJECT_ID}" >/dev/null 2>&1 || \
gcloud iam service-accounts create "${GSA_NAME}" \
  --project "${PROJECT_ID}" \
  --display-name "Anime API GKE BigQuery service account"

gcloud projects add-iam-policy-binding "${PROJECT_ID}" \
  --member "serviceAccount:${GSA_EMAIL}" \
  --role "roles/bigquery.jobUser"

gcloud projects add-iam-policy-binding "${PROJECT_ID}" \
  --member "serviceAccount:${GSA_EMAIL}" \
  --role "roles/bigquery.dataViewer"

gcloud iam service-accounts add-iam-policy-binding "${GSA_EMAIL}" \
  --project "${PROJECT_ID}" \
  --role "roles/iam.workloadIdentityUser" \
  --member "serviceAccount:${PROJECT_ID}.svc.id.goog[${NAMESPACE}/${KSA_NAME}]"

kubectl annotate serviceaccount "${KSA_NAME}" \
  -n "${NAMESPACE}" \
  "iam.gke.io/gcp-service-account=${GSA_EMAIL}" \
  --overwrite

echo "Workload Identity configured. Restart analytics/recommendations pods after applying this if they are already running."
