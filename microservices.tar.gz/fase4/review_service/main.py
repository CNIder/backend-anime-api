from flask import Flask, request
from flask_restful import Resource, Api
import logging
import csv

app = Flask(__name__)
api = Api(app)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("ReviewService")

reviews = []
review_id_counter = 1

def load_reviews_from_csv():
    global reviews, review_id_counter

    try:
        with open('reviews.csv', newline='', encoding='utf-8') as csvfile:
            reader = csv.DictReader(csvfile)

            for row in reader:
                review = {
                    "id": int(row["id"]),
                    "user_id": int(row["user_id"]),
                    "anime_id": int(row["anime_id"]),
                    "rating": int(row["rating"]),
                    "comment": row["comment"]
                }
                reviews.append(review)

            # garantir que o próximo ID não colide
            if reviews:
                review_id_counter = max(r["id"] for r in reviews) + 1

        logger.info("Reviews loaded from CSV")

    except FileNotFoundError:
        logger.warning("reviews.csv not found, starting with empty dataset")


class ReviewList(Resource):
    def get(self):
        anime_id = request.args.get("anime_id")

        if anime_id is not None:
            anime_id = int(anime_id)
            return [r for r in reviews if r["anime_id"] == anime_id]

        return reviews

    def post(self):
        global review_id_counter
        data = request.json

        # validação básica
        required = ["user_id", "anime_id", "rating"]
        for field in required:
            if field not in data:
                return {"error": f"{field} is required"}, 400

        review = {
            "id": review_id_counter,
            "user_id": data["user_id"],
            "anime_id": data["anime_id"],
            "rating": data["rating"],
            "comment": data.get("comment", "")
        }

        review_id_counter += 1
        reviews.append(review)

        logger.info(f"Review created: {review}")

        return review, 201


class Review(Resource):
    def get(self, id):
        for r in reviews:
            if r["id"] == id:
                return r
        return {"error": "Review not found"}, 404

    def put(self, id):
        data = request.json

        for r in reviews:
            if r["id"] == id:
                r["rating"] = data.get("rating", r["rating"])
                r["comment"] = data.get("comment", r["comment"])
                return r

        return {"error": "Review not found"}, 404

    def delete(self, id):
        global reviews
        reviews = [r for r in reviews if r["id"] != id]
        return {"message": "Review deleted"}


api.add_resource(ReviewList, '/reviews')
api.add_resource(Review, '/reviews/<int:id>')


if __name__ == '__main__':
    load_reviews_from_csv()
    app.run(host='0.0.0.0', port=5001)