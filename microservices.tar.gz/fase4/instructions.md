# Instructions

## Microservices
We have 2 microservices built on docker images to be executed as containers. Inside each directory, execute the following commands:

> cd review-service/
> docker build -t review_service .
> docker run -p 5001:5001 review_service

Available endpoint: localhost:5001/reviews

> cd forum-service/
> docker build -t forum_service .
> docker run -p 5002:5002 forum_service

Available endpoint: localhost:5002/posts
http://localhost:5002/posts/<post_id>
http://localhost:5002/posts/<post_id>/comments